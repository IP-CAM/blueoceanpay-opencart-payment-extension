<?php

$order_id = -1;
if (!empty($_GET["order_id"])) {
    $order_id = $_GET["order_id"];
}

if (!empty($_GET["industry_type"])) {
    $industry_type = $_GET["industry_type"];
    if ($industry_type == "cashier_o2o") {
        $cash_o2o_type = $_GET["cash_o2o_type"];
    }
    if ($industry_type == "orderingretail") {
        if (!empty($_GET["opt"])) {
            $opt = $_GET["opt"]; //是否是转上级操作
        } else {
            $opt = "stock";
        }
    }

    if ($industry_type == "cityarea") {
        $is_merge  = $_GET["is_merge"];
        $city_type = $_GET["city_type"];
    }
}

$link = mysql_connect(DB_HOST, DB_USER, DB_PWD);
mysql_select_db(DB_NAME) or die('Could not select database');
require_once LocalBaseURL . "public_method/handle_order_function.php";
require_once LocalBaseURL . 'common/common_from.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/wsy_pay/sdk/IndustryOpeInstance.php';

$log_name = LocalBaseURL . "log/blueoceanpay_" . date('Ymd') . ".log"; //log文件路径
file_put_contents($log_name, "\n\n blueoceanpay  : order_id : " . $order_id . " == " . date("Y-m-d H:i:s") . "\n", FILE_APPEND);



// 获取支付方式配置信息
$query = "SELECT
            appid,
            appsecret
        FROM
            pay_config
        WHERE
            pay_type = 'blueoceanpay'
        AND
            isvalid = 1
        AND
            customer_id = $customer_id
        LIMIT 1 ";

$result = _mysql_query($query) or die('Query failed5182: ' . mysql_error());

$appid     = '';
$appsecret = '';
while ($row = mysql_fetch_object($result)) {
    $appid     = $row->appid;
    $appsecret = $row->fee_type;
    break;
}


// 获取 openid.
$original = 'https://m102.backend.hk' . $_SERVER['REQUEST_URI'];
$openid_url = "http://auth.hk.blueoceanpay.com/wechat/user/getOpenId?merchant=$appid&original=$original";

$openid = "";

if (isset($_GET['reponse'])) {
    $data = json_decode($_GET['reponse']);
    print($data);
    exit;
} else {
    echo "<script>location.href='" . $openid_url . "'</script>";
    exit;
}





//使用jsapi接口
$jsApi  = new JsApi_pub();

//=========步骤2：使用统一支付接口，获取prepay_id============
$old_batchcode_str = $order_id;
//查询订单数据
$extra = array();
if ($industry_type == "orderingretail") {
    $extra['opt'] = $opt;
}
if ($industry_type == "cityarea") {
    $extra['is_merge'] = $is_merge;
}

// 获取订单信息
$data = query_order($customer_id, $order_id, $industry_type, "", "weipay", $extra); //调用查询订单数据方法

//订单已支付
if ($data['paystatus'] == 10001) {
    die();
}

$totalprice = round($data['totalprice'], 2) * 100; //微信金额转换

$pnamearr = $data['pnamearr'];
$order_id = $data['order_id'];
if ($industry_type == "travel_card") {
    $pnamearr     = "travel_card";
    $order_id     = $_GET["order_id"];
    $query_order  = "select real_pay from " . WSY_O2O . ".travel_card_order where batchcode='" . $order_id . "'";
    $result_order = _mysql_query($query_order) or die('Query failed:' . mysql_error());
    while ($row_order = mysql_fetch_assoc($result_order)) {
        $order_info = $row_order;
        $totalprice = round($order_info['real_pay'], 2) * 100;
    }
}

$is_collageActivities = $data['is_collageActivities'];
$attach_arr           = array(
    "industry_type" => $industry_type,
); //额外参数

//如果是订货系统类型，返回供货商id
if ($industry_type == "orderingretail") {
    $supplier_id       = $data['supplier_id'];
    $attach_arr['opt'] = $opt;
}
if ($industry_type == "cityarea") {
    $attach_arr['is_merge'] = $is_merge;
}

$attach_str = json_encode($attach_arr, true); //转换成json格式
$fromuser   = "";
$query      = "select weixin_fromuser from weixin_users where id='" . $user_id . "' and isvalid=1 limit 1";
$result     = _mysql_query($query) or die('Query failed:' . mysql_error());
while ($row = mysql_fetch_assoc($result)) {
    $user_info = $row;
    $fromuser  = $user_info['weixin_fromuser'];
}
if ($openid != $fromuser) {
    echo "用户信息不一致,不能支付!";die;
}


//保存微信支付订单
save_weipay_log($customer_id, $order_id, $industry_type, $old_batchcode_str);

//使用统一支付接口
$unifiedOrder = new UnifiedOrder_pub();

$unifiedOrder->setParameter("openid", "$openid"); //商品描述
$unifiedOrder->setParameter("body", "$pnamearr"); //商品描述
//自定义订单号，此处仅作举例
$timeStamp = time();
//$out_trade_no = $pid;
$unifiedOrder->setParameter("out_trade_no", $order_id); //商户订单号
$unifiedOrder->setParameter("total_fee", $totalprice); //总金额
$unifiedOrder->setParameter("notify_url", NOTIFY_URL); //通知地址
$unifiedOrder->setParameter("trade_type", "JSAPI"); //交易类型

/*****微信境外支付开始****/
$query = 'SELECT fee_type,sub_mch_id,attach FROM pay_config where isvalid=true and customer_id=' . $customer_id . " limit 0,1";

$attach_shop = '';
$fee_type    = '';
$sub_mch_id  = '';
$result      = _mysql_query($query) or die('Query failed5182: ' . mysql_error());
while ($row = mysql_fetch_object($result)) {
    $attach_shop = $row->attach;
    $fee_type    = $row->fee_type;
    $sub_mch_id  = $row->sub_mch_id;
    break;
}
if (!$attach_shop) {
    $unifiedOrder->setParameter("attach", $attach_str); //附加数据 行业类型
} else {
    $unifiedOrder->setParameter("attach", $attach_shop); //附加数据  境外支付门店授权码
    $unifiedOrder->setParameter("device_info", $attach_str); //如果attach字段被占用改用device_info字段 行业类型
}

if ($sub_mch_id && !$attach_shop) {
    $unifiedOrder->setParameter("sub_mch_id", $sub_mch_id); //子商户号
}

if ($fee_type) {
    $unifiedOrder->setParameter("fee_type", $fee_type); //币种
}

$prepay_id = $unifiedOrder->getPrepayId();
if (empty($prepay_id)) {
    echo 'PaySignKey参数错误';
    die();
}
// echo 'prepay_id:'.$prepay_id;
// die();
//=========步骤3：使用jsapi调起支付============
$jsApi->setPrepayId($prepay_id);

$jsApiParameters = $jsApi->getParameters();
file_put_contents($log_name, "\n\n $jsApiParameters : " . var_export($jsApiParameters, true) . "\n", FILE_APPEND);

$batchcode_arr                  = explode("_", $old_batchcode_str);
$data_arr['batchcode']          = $batchcode_arr[0];
$data_arr['return_batchcode']   = $order_id;
$data_arr['city_type']          = $city_type;
$data_arr['orderingretail_opt'] = $opt;
$data_arr['return_status']      = "";
$data_arr['supplier_id']        = "";
$data_arr['cash_o2o_type']      = $cash_o2o_type;

if ($industry_type == "travel_card") {
    $return['return_page'] = "/o2o/web/view/travel/my_travelCard.html?customer_id=" . $customer_id;
} else {
    require_once "../../../wsy_pay/sdk/IndustryOpeInstance.php";
    $industry_obj = \Wsy\Pay\IndustryOpeInstance::getIndustryObject($industry_type, $customer_id);
    $return       = $industry_obj->getReturnPage($data_arr);
}

mysql_close($link);
?>

<html>
<head>

    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <title>蓝海支付</title>
    <script type="text/javascript">
    var customer_id = '<?php echo $customer_id; ?>';
    var customer_id_en = "<?php echo $customer_id_en; ?>";
    var return_page = "<?php echo $return['return_page']; ?>";

        //调用微信JS api 支付
        function jsApiCall()
        {
            WeixinJSBridge.invoke(
                'getBrandWCPayRequest',
                <?php echo $jsApiParameters; ?>,
                function(res){
                    //WeixinJSBridge.log(res.err_msg);
                        var msg = res.err_msg;
                        var p_stu = false;  //微信支付状态 默认：false
                        var url = "";

                       if(msg=="get_brand_wcpay_request:ok"){

                           p_stu = true;
                           document.location="<?php echo $protocol_http_host; ?>"+return_page;
                       }else{
                          win_alert('支付失败！');
                       }
                }
            );
        }

        function callpay()
        {
            if (typeof WeixinJSBridge == "undefined"){
                alert(555);
                if( document.addEventListener ){
                    document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
                }else if (document.attachEvent){
                    document.attachEvent('WeixinJSBridgeReady', jsApiCall);
                    document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
                }
            }else{
                jsApiCall();
            }
        }
         document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {
        // alert('call=============1');
           callpay();

        })
    </script>
    <?php
$link = mysql_connect(DB_HOST, DB_USER, DB_PWD);
mysql_select_db(DB_NAME) or die('Could not select database');
require_once LocalBaseURL . 'common/common_from.php';
require_once LocalBaseURL . 'common/share.php';
?>
</head>
<body>
</body>
</html>