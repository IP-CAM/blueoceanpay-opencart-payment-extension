<?php

// Heading
$_['heading_title']              = 'Blueocean Pay';

// Text
$_['text_title']                 = 'Blueocean Pay';
$_['text_checkout']              = 'Checkout';
$_['text_qrcode']                = 'QrCode';
$_['text_qrcode_description']    = 'Please scan the QR code in WeChat app to pay your order!';
